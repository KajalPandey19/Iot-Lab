<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Cart extends CI_Controller {
    public function __construct() {
        parent::__construct();
        $this->load->model('Cart_model'); // Load the Cart model
        header("Access-Control-Allow-Origin: *");
        header("Access-Control-Allow-Headers: Content-Type");
        header("Access-Control-Allow-Methods: POST, GET, PUT, DELETE");
    }

    // Add product to cart
    public function add() {
        $data = json_decode(file_get_contents("php://input"), true);
        // Validate input data
        if (!$data['productId'] || !$data['quantity']) {
            echo json_encode(['status' => 'error', 'message' => 'User  ID, Product ID, and Quantity are required.']);
            return;
        }
        
        // echo json_encode(['status' => 'error', 'message' => $data]);
        //     return;
        // Attempt to add the product to the cart
        if ($this->Cart_model->add_to_cart($data)) {
            echo json_encode(['status' => 'success', 'message' => 'Product added to cart.']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Failed to add product to cart.']);
        }
    }
    public function get_all() {
        $cart_items = $this->Cart_model->get_cart_items();
        // Ensure the keys match what the frontend expects
        echo json_encode(['status' => 'success', 'cartItems' => $cart_items]);
    }

    // Get cart items for a user
    public function get_cart($product_id) {
        $cart_items = $this->Cart_model->get_cart_items($product_id);
        // Ensure the keys match what the frontend expects
        echo json_encode(['status' => 'success', 'cartItems' => $cart_items]);
    }

    // Update quantity of a cart item
    public function update($id) {
        $data = json_decode(file_get_contents("php://input"), true);
        
        // Validate input data
        if (empty($data['quantity'])) {
            echo json_encode(['status' => 'error', 'message' => 'Quantity is required.']);
            return;
        }

        // Attempt to update the cart item
        if ($this->Cart_model->update_cart_item($id, $data['quantity'])) {
            echo json_encode(['status' => 'success', 'message' => 'Cart item updated.']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Failed to update cart item.']);
        }
    }

    // Remove an item from the cart
    public function remove($id) {
        if ($this->Cart_model->remove_cart_item($id)) {
            echo json_encode(['status' => 'success', 'message' => 'Cart item removed.']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Failed to remove cart item.']);
        }
    }
}