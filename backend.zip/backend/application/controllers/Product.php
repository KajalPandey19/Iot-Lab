<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Product extends CI_Controller {
    public function __construct() {
        parent::__construct();
        $this->load->model('Product_model'); // Load the Product model
        header("Access-Control-Allow-Origin: *");
        header("Access-Control-Allow-Headers: Content-Type");
        header("Access-Control-Allow-Methods: POST, GET, PUT, DELETE");
    }

    // Create a new product
    public function create() {
        $data = json_decode(file_get_contents("php://input"), true);
        
        // Validate input data
        if (empty($data['name']) || empty($data['description']) || empty($data['price']) || empty($data['category_id']) || empty($data['stock'])) {
            echo json_encode(['status' => 'error', 'message' => 'All fields are required.']);
            return;
        }

        // Attempt to create the product
        if ($this->Product_model->create($data)) {
            echo json_encode(['status' => 'success']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Product creation failed.']);
        }
    }

    // Read all products
    public function read() {
        $products = $this->Product_model->get_all();
        echo json_encode(['status' => 'success', 'products' => $products]);
    }

    // Read a single product by ID
    public function read_single($id) {
        $product = $this->Product_model->get_by_id($id);
        if ($product) {
            echo json_encode(['status' => 'success', 'product' => $product]);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Product not found.']);
        }
    }

    // Update a product
    public function update($id) {
        $data = json_decode(file_get_contents("php://input"), true);
        
        // Validate input data
        if (empty($data['name']) || empty($data['description']) || empty($data['price']) || empty($data['category_id']) || empty($data['stock'])) {
            echo json_encode(['status' => 'error', 'message' => 'All fields are required.']);
            return;
        }

        // Attempt to update the product
        if ($this->Product_model->update($id, $data)) {
            echo json_encode(['status' => 'success']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Product update failed.']);
        }
    }

    // Delete a product
    public function delete($id) {
        if ($this->Product_model->delete($id)) {
            echo json_encode(['status' => 'success']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Product deletion failed.']);
        }
    }
    // In Product.php controller
public function read_by_category($categoryId) {
    // Fetch products by category ID
    $this->db->where('category_id', $categoryId);
    $query = $this->db->get('products');
    $products = $query->result_array();

    if ($products) {
        echo json_encode(['status' => 'success', 'products' => $products]);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'No products found for this category.']);
    }
}
}