<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Category extends CI_Controller {
    public function __construct() {
        parent::__construct();
        $this->load->model('Category_model'); // Load the Category model
        header("Access-Control-Allow-Origin: *");
        header("Access-Control-Allow-Headers: Content-Type");
        header("Access-Control-Allow-Methods: POST, GET, PUT, DELETE");
    }

    // Create a new category
    public function create() {
        $data = json_decode(file_get_contents("php://input"), true);
        
        // Log incoming data for debugging
        log_message('debug', 'Create category data: ' . json_encode($data));
        
        // Validate input data
        if (empty($data['name'])) {
            echo json_encode(['status' => 'error', 'message' => 'Category name is required.']);
            return;
        }

        // Attempt to create the category
        if ($this->Category_model->create($data)) {
            echo json_encode(['status' => 'success']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Category creation failed.']);
        }
    }

    // Read all categories
    public function read() {
        $categories = $this->Category_model->get_all();
        echo json_encode(['status' => 'success', 'categories' => $categories]);
    }

    // Read a single category by ID
    public function read_single($id) {
        $category = $this->Category_model->get_by_id($id);
        if ($category) {
            echo json_encode(['status' => 'success', 'category' => $category]);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Category not found.']);
        }
    }

    // Update a category
    public function update($id) {
        $data = json_decode(file_get_contents("php://input"), true);
        
        // Validate input data
        if (empty($data['name'])) {
            echo json_encode(['status' => 'error', 'message' => 'Category name is required.']);
            return;
        }

        // Attempt to update the category
        if ($this->Category_model->update($id, $data)) {
            echo json_encode(['status' => 'success']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Category update failed.']);
        }
    }

    // Delete a category
    public function delete($id) {
        if ($this->Category_model->delete($id)) {
            echo json_encode(['status' => 'success']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Category deletion failed.']);
        }
    }
 }




// defined('BASEPATH') OR exit('No direct script access allowed');

// class Category extends CI_Controller {
//     public function __construct() {
//         parent::__construct();
//         $this->load->model('Category_model'); // Load the Category model
//         header("Access-Control-Allow-Origin: *");
//         header("Access-Control-Allow-Headers: Content-Type");
//         header("Access-Control-Allow-Methods: POST, GET, PUT, DELETE");
//     }

//     public function create() {
//         error_reporting(E_ALL);
//         ini_set('display_errors', 1);
    
//         if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
//             echo json_encode(['status' => 'error', 'message' => 'Invalid request method.']);
//             return;
//         }
    
//         if (empty($_POST['name'])) {
//             echo json_encode(['status' => 'error', 'message' => 'Category name is required.']);
//             return;
//         }
    
//         $name = $_POST['name'];
//         $image_path = null;
    
//         if (isset($_FILES['image']) && $_FILES['image']['error'] == UPLOAD_ERR_OK) {
//             $upload_dir = './uploads/'; // Ensure this directory exists and is writable
//             $image_path = $upload_dir . basename($_FILES['image']['name']);
            
//             if (!move_uploaded_file($_FILES['image']['tmp_name'], $image_path)) {
//                 echo json_encode(['status' => 'error', 'message' => 'Failed to upload image.']);
//                 return;
//             }
//         }
    
//         // Save the category to the database
//         $data = [
//             'name' => $name,
//             'image' => $image_path
//         ];
    
//         if ($this->Category_model->create($data)) {
//             echo json_encode(['status' => 'success', 'message' => 'Category created successfully.']);
//         } else {
//             echo json_encode(['status' => 'error', 'message' => 'Failed to create category.']);
//         }
//     }
      
//     // Read all categories
//     public function read() {
//         header('Content-Type: application/json'); // Set the content type to JSON
//         $categories = $this->Category_model->get_all();
        
//         if ($categories) {
//             echo json_encode(['status' => 'success', 'categories' => $categories]);
//         } else {
//             echo json_encode(['status' => 'error', 'message' => 'No categories found.']);
//         }
//     }

//     // Read a single category by ID
//     public function read_single($id) {
//         header('Content-Type: application/json'); // Set the content type to JSON
//         $category = $this->Category_model->get_by_id($id);
//         if ($category) {
//             echo json_encode(['status' => 'success', 'category' => $category]);
//         } else {
//             echo json_encode(['status' => 'error', 'message' => 'Category not found.']);
//         }
//     }

//     // Update a category
//     public function update($id) {
//         $data = [];
        
//         // Handle image upload if a new image is provided
//         if (isset($_FILES['image']) && $_FILES['image']['error'] == UPLOAD_ERR_OK) {
//             $config['upload_path'] = './uploads/'; // Ensure this directory exists and is writable
//             $config['allowed_types'] = 'jpg|jpeg|png|gif';
//             $config['max_size'] = 2048; // 2MB
//             $this->load->library('upload', $config);

//             if (!$this->upload->do_upload('image')) {
//                 echo json_encode(['status' => 'error', 'message' => $this->upload->display_errors()]);
//                 return;
//             } else {
//                 $upload_data = $this->upload->data();
//                 $data['image'] = 'uploads/' . $upload_data['file_name']; // Save the file path
//             }
//         }

//         // Get the category name from the request
//         $data['name'] = $this->input->post('name');

//         // Validate input data
//         if (empty($data['name'])) {
//             echo json_encode(['status' => 'error', 'message' => 'Category name is required.']);
//             return;
//         }

//         // Attempt to update the category
//         if ($this->Category_model->update($id, $data)) {
//             echo json_encode(['status' => 'success']);
//         } else {
//             echo json_encode(['status' => 'error', 'message' => 'Category update failed.']);
//         }
//     }

//     // Delete a category
//     public function delete($id) {
//         header('Content-Type: application/json'); // Set the content type to JSON
//         if ($this->Category_model->delete($id)) {
//             echo json_encode(['status' => 'success']);
//         } else {
//             echo json_encode(['status' => 'error', 'message' => 'Category deletion failed.']);
//         }
//     }
// }