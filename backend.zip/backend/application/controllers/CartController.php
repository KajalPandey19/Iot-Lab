<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class CartController extends CI_Controller {
    public function __construct() {
        parent::__construct();
        $this->load->model('CartModel');
        // $this->load->model('ProductModel');
        header("Access-Control-Allow-Origin: *");
        header("Access-Control-Allow-Headers: Content-Type, Authorization");
        header("Access-Control-Allow-Methods: POST, GET, DELETE");
    }

    // Add product to cart
    public function add_to_cart() {
     
        // Check if the request is a POST request
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $inputData = json_decode($this->input->raw_input_stream, true);
   
            // Log the input data
            log_message('debug', 'Received data: ' . print_r($inputData, true));
       
            $userId = $inputData['user_id'];
            $productId = $inputData['product_id'];
            $quantity = $inputData['quantity'];
   
            // Debugging: Check the data received
            log_message('debug', "userId: $userId, productId: $productId, quantity: $quantity");
           
            if (empty($userId)) {
                echo json_encode(['status' => 'error', 'message' => 'User ID is required']);
                return;
            }
            if ($this->CartModel->add_to_cart($userId, $productId, $quantity)) {
                echo json_encode(['status' => 'success', 'message' => 'Product added to cart']);
            } else {
                echo json_encode(['status' => 'error', 'message' => 'Failed to add to cart', 'error_details' => $this->db->error()]);
            }
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Invalid request method']);
        }
    }
   

    // Retrieve cart items for a user
    public function get_user_cart($userId) {
        $cartItems = $this->CartModel->get_user_cart($userId);
        echo json_encode(['status' => 'success', 'data' => $cartItems]);
    }

    // Delete item from cart
    public function remove_from_cart($userId, $productId) {
        $this->load->model('CartModel');
        $result = $this->CartModel->removeFromCart($userId, $productId);
        echo json_encode($result);
    }
    // CartController.php
public function update_quantity() {
    $userId = $this->input->post('userId');
    $productId = $this->input->post('productId');
    $quantity = $this->input->post('quantity');

    $this->load->model('CartModel');
    $result = $this->CartModel->updateQuantity($userId, $productId, $quantity);
    echo json_encode($result);
}

    // Empty the cart
    public function empty_cart($userId) {
        $this->load->model('CartModel');
        $result = $this->CartModel->emptyCart($userId);
        echo json_encode($result);
    }
}
