<?php
defined('BASEPATH') OR exit('No direct script access allowed');

// OrderController.php
class OrderController extends CI_Controller {
    public function __construct() {
        parent::__construct();
        $this->load->model('Order_model'); // Ensure the model is loaded correctly
        header("Access-Control-Allow-Origin: *");
        header("Access-Control-Allow-Headers: Content-Type, Authorization");
        header("Access-Control-Allow-Methods: POST, GET, DELETE");
    }
    public function place_order() {
        $postData = json_decode(file_get_contents("php://input"), true);
        $userId = $postData['userId'];
        $cartItems = $postData['cartItems'];

        $paymentMethod = $postData['paymentMethod'];

        $orderData = [
            'user_id' => $userId,
            'total_amount' => $totalAmount,
            'delivery_date' => $deliveryDate,
            'payment_method' => $paymentMethod,
            'status' => 'Pending'
        ];

        // Save order in the orders table
        $this->db->insert('orders', $orderData);
        $orderId = $this->db->insert_id();



        echo json_encode(['status' => 'success', 'message' => 'Order placed successfully']);
    }
    public function get_order_history($userId) {
        $orders = $this->Order_model->get_user_orders($userId);
   
        if ($orders !== false) {
            echo json_encode(['status' => 'success', 'data' => $orders]);
        } else {
            http_response_code(500); // Set HTTP response code to 500 for error handling
            echo json_encode(['status' => 'error', 'message' => 'Failed to retrieve orders']);
        }
    }
    public function get_all_orders() {
        $orders = $this->Order_model->get_all_orders();
        if ($orders) {
            echo json_encode(['status' => 'success', 'data' => $orders]);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'No orders found']);
        }
    }
    public function update_order_status($orderId) {
        $postData = json_decode(file_get_contents("php://input"), true);
        $status = $postData['status'];
   
        if ($this->Order_model->update_order_status($orderId, $status)) {
            echo json_encode(['status' => 'success', 'message' => 'Order status updated']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Failed to update status']);
        }
    }
    public function view_order($orderId) {
        $orderDetails = $this->Order_model->get_order_details($orderId);
        if ($orderDetails) {
            echo json_encode(['status' => 'success', 'data' => $orderDetails]);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Order not found']);
        }
    }
   
    public function edit_order($orderId) {
        $postData = json_decode(file_get_contents("php://input"), true);
        $status = $postData['status'];
   
        if ($this->Order_model->update_order_status($orderId, $status)) {
            echo json_encode(['status' => 'success', 'message' => 'Order status updated']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Failed to update order status']);
        }
    }
   
    public function delete_order($orderId) {
        if ($this->Order_model->delete_order($orderId)) {
            echo json_encode(['status' => 'success', 'message' => 'Order deleted successfully']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Failed to delete order']);
        }
    }
   
   
}
