<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Cart_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }

    // Add product to the cart
    public function add_to_cart($data) {
        // Check if the product is already in the cart
        //$this->db->where('user_id', $data['user_id']);
        $this->db->where('product_id', $data['productId']);
        $query = $this->db->get('shopping_cart');

        if ($query->num_rows() > 0) {
            // If product exists, update the quantity
            //$this->db->where('user_id', $data['user_id']);
            $this->db->where('product_id', $data['product_id']);
            return $this->db->update('shopping_cart', ['quantity' => $data['quantity']]);
        } else {
            // If product does not exist, insert a new record
            return $this->db->insert('shopping_cart', $data);
        }
    }
    
    public function get_all() {
        // Retrieve all products from the database
        $query = $this->db->get('shoppping_cart');
        return $query->result_array();
    }

    // Get all cart items for a user
    public function get_cart_items($product_id) {
        $this->db->where('product_id', $product_id);
        $query = $this->db->get('shopping_cart');
        return $query->result_array();
    }

    // Update quantity of a cart item
    public function update_cart_item($id, $quantity) {
        $this->db->where('id', $id);
        return $this->db->update('shopping_cart', ['quantity' => $quantity]);
    }

    // Remove an item from the cart
    public function remove_cart_item($id) {
        return $this->db->delete('shopping_cart', ['id' => $id]);
    }
}