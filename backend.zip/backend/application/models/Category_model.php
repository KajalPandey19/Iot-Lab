
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Category_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }

    public function create($data) {
        // Add the category to the database
        $this->db->insert('categories', $data);
        if ($this->db->affected_rows() > 0) {
            return true;
        } else {
            log_message('error', 'Category creation failed: ' . $this->db->last_query());
            return false;
        }
    }

    public function get_all() {
        // Retrieve all categories from the database
        $query = $this->db->get('categories');
        return $query->result_array();
    }

    public function get_by_id($id) {
        // Retrieve a category by its ID
        $query = $this->db->get_where('categories', ['id' => $id]);
        return $query->row_array();
    }

    public function update($id, $data) {
        // Update the category in the database
        $this->db->where('id', $id);
        return $this->db->update('categories', $data);
    }

    public function delete($id) {
        // Delete the category from the database
        return $this->db->delete('categories', ['id' => $id]);
    }
}



// defined('BASEPATH') OR exit('No direct script access allowed');

// class Category_model extends CI_Model {

//     public function __construct() {
//         parent::__construct();
//     }

//     public function create($data) {
//         // Add the category to the database
//         $this->db->insert('categories', $data);
//         if ($this->db->affected_rows() > 0) {
//             return true;
//         } else {
//             log_message('error', 'Category creation failed: ' . $this->db->last_query());
//             return false;
//         }
//     }

//     public function get_all() {
//         // Retrieve all categories from the database
//         $query = $this->db->get('categories');
//         return $query->result_array();
//     }

//     public function get_by_id($id) {
//         // Retrieve a category by its ID
//         $query = $this->db->get_where('categories', ['id' => $id]);
//         return $query->row_array();
//     }

//     public function update($id, $data) {
//         // Update the category in the database
//         $this->db->where('id', $id);
//         return $this->db->update('categories', $data);
//     }

//     public function delete($id) {
//         // Delete the category from the database
//         return $this->db->delete('categories', ['id' => $id]);
//     }
// } -->