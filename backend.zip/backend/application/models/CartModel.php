<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class CartModel extends CI_Model {

    // Add item to cart table
    public function add_to_cart($userId, $productId, $quantity) {
        $this->db->where('user_id', $userId);
    $this->db->where('product_id', $productId);
    $existingItem = $this->db->get('shopping_cart')->row_array();

    if ($existingItem) {
        // If product exists, increment the quantity
        $this->db->set('quantity', 'quantity + ' . $quantity, FALSE);
        $this->db->where('user_id', $userId);
        $this->db->where('product_id', $productId);
        $this->db->update('shopping_cart');
    } else {
        // If product doesn't exist, add as new entry
        $this->db->insert('shopping_cart', [
            'user_id' => $userId,
            'product_id' => $productId,
            'quantity' => $quantity
        ]);
    }

    return ['status' => 'success'];
    }
   
    // CartModel.php
public function updateQuantity($userId, $productId, $quantity) {
    $this->db->where('user_id', $userId);
    $this->db->where('product_id', $productId);
    $this->db->update('shopping_cart', ['quantity' => $quantity]);
    return ['status' => 'success'];
}

    // Get all cart items for a specific user
    public function get_user_cart($userId) {
        $this->db->select('shopping_cart.id, shopping_cart.product_id, products.name, products.price,shopping_cart.quantity, (products.price * shopping_cart.quantity) AS total');
        $this->db->from('shopping_cart');
        $this->db->join('products', 'shopping_cart.product_id = products.id');
        $this->db->where('shopping_cart.user_id', $userId);
        return $this->db->get()->result_array();
    }
   

    // Remove item from cart
    public function removeFromCart($userId, $productId) {
        $this->db->where('user_id', $userId);
        $this->db->where('product_id', $productId);
        $this->db->delete('shopping_cart');
        return ['status' => 'success'];
    }

    // Empty the entire cart
    public function emptyCart($userId) {
        $this->db->where('user_id', $userId);
        $this->db->delete('shopping_cart');
        return ['status' => 'success'];
    }
}
