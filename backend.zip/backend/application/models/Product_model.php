<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Product_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }

    public function create($data) {
        // Add the product to the database
        $this->db->insert('products', $data);
        return $this->db->affected_rows() > 0;
    }

    public function get_all() {
        // Retrieve all products from the database
        $query = $this->db->get('products');
        return $query->result_array();
    }

    public function get_by_id($id) {
        // Retrieve a product by its ID
        $query = $this->db->get_where('products', ['id' => $id]);
        return $query->row_array();
    }

    public function update($id, $data) {
        // Update the product in the database
        $this->db->where('id', $id);
        return $this->db->update('products', $data);
    }

    public function delete($id) {
        // Delete the product from the database
        return $this->db->delete('products', ['id' => $id]);
    }
}