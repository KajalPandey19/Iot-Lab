<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Order_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }

    // Add a new order
    public function add_order($userId, $totalAmount, $paymentMethod, $deliveryDate, $orderItems) {
        // Insert into orders table
        $data = [
            'user_id' => $userId,
            'total_amount' => $totalAmount,
            'payment_method' => $paymentMethod,
            'delivery_date' => $deliveryDate,
            'status' => 'Pending', // Default order status
        ];

        // Start transaction
        $this->db->trans_start();

        // Insert order into the orders table
        $this->db->insert('orders', $data);
        $orderId = $this->db->insert_id();  // Get the inserted order ID

        // Insert each order item into the order_items table
        foreach ($orderItems as $item) {
            $orderItemData = [
                'order_id' => $orderId,
                'product_id' => $item['product_id'],
                'quantity' => $item['quantity'],
                'price' => $item['price'],
            ];
            $this->db->insert('order_items', $orderItemData);
        }

     
    }

    // Get all orders for a specific user
    public function get_user_orders($userId) {
        // Select the necessary fields from orders and order_items
        $this->db->select('orders.order_id, orders.total_amount, orders.payment_method, orders.delivery_date, orders.status, orders.created_at, order_items.product_id, order_items.quantity, order_items.price');
        $this->db->from('orders');
        $this->db->join('order_items', 'orders.order_id = order_items.order_id');
        $this->db->where('orders.user_id', $userId);
        $this->db->order_by('orders.created_at', 'DESC');  // Order by most recent first

        // Execute the query and return the result
        $query = $this->db->get();
        if (!$query) {
            // Log or display the error message
            log_message('error', 'Database error: ' . $this->db->last_query());
            log_message('error', 'Error message: ' . $this->db->error()['message']);
            return false;
        }
        return $query->result_array();  // Return the result as an array
    }

    // Get the details of a specific order by order ID
    public function get_order_details($orderId) {
        $this->db->select('orders.*, order_items.product_id, order_items.quantity, order_items.price');
        $this->db->from('orders');
        $this->db->join('order_items', 'orders.order_id = order_items.order_id');
        $this->db->where('orders.order_id', $orderId);

        $query = $this->db->get();
        return $query->result_array();  // Return the result as an array
    }

    // Update the status of an order
    public function update_order_status($orderId, $status) {
        $this->db->set('status', $status);
        $this->db->where('order_id', $orderId);
        return $this->db->update('orders');
    }

    // Get all orders (for admin view)
    public function get_all_orders() {
        $this->db->select('orders.*, users.username, users.email');
        $this->db->from('orders');
        $this->db->join('users', 'orders.user_id = users.id');
        $this->db->order_by('orders.created_at', 'DESC');  // Order by most recent first
        $query = $this->db->get();
        return $query->result_array();  // Return the result as an array
    }
   
   
   
   
    public function delete_order($orderId) {
        // Delete order items first
        $this->db->where('order_id', $orderId);
        $this->db->delete('order_items');
   
        // Then delete the order itself
        $this->db->where('order_id', $orderId);
        return $this->db->delete('orders');
    }
   
}

