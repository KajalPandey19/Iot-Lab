<?php
echo "Server is working!";
?>
